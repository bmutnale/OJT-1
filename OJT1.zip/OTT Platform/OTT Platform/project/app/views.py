from django.shortcuts import render, HttpResponse
from app.models import Directors
from app.models import Category
from app.models import Package
from app.models import AdminMaster
from app.models import Language
from app.models import ReleaseCategory
from app.models import Movie
from app.models import Registration
from app.models import Order
from app.models import tvSeries
from app.models import tvEpisodes
from app.models import Review
from mailjet_rest import Client


# from app.models import Signin

from django.http import  JsonResponse
from django.http import HttpResponse,HttpResponseRedirect
from django.shortcuts import redirect, render, HttpResponse



# Create your views here

# web pages templates

def aboutweb(request):
    return render(request,'web/about.html')

def catalog1(request):
    return render(request,'web/catalog1.html')

def catalog2(request):
    return render(request,'web/catalog2.html')


def details1(request):
    if 'user_email' in request.session:
        checkOrder =  Order.objects.filter(or_email = request.session['user_email']).count()
        if checkOrder == 0:
            return render(request,'web/pricing.html')
        else:
            return render(request,'web/details1.html')
    else:
        return render(request,'web/signin.html')


def details2(request):
    if 'user_email' in request.session:
        checkOrder =  Order.objects.filter(or_email = request.session['user_email']).count()
        if checkOrder == 0:
            return render(request,'web/pricing.html')
        else:
            return render(request,'web/details2.html')
    else:
        return render(request,'web/signin.html')

def faq(request):
    return render(request,'web/faq.html')

def index(request):
    return render(request,'web/index.html')

def index2(request):
    return render(request,'web/index2.html')

def pricing(request):
    return render(request,'web/pricing.html')

def signin(request):
    return render(request,'web/signin.html')

def signup(request):
    return render(request,'web/signup.html')

def welcome(request):
    return render(request,'web/welcome.html')

def payment(request):
    return render(request,'web/payment.html')

# admin panel

def adindex1(request):
    return render(request,'admin/adindex.html')

def adsignin1(request):
    return render(request,'admin/signin.html')

def adsignup1(request):
    return render(request,'admin/signup.html')

def adpackage(request):
    return render(request,'admin/package.html')

def admcategory(request):
    return render(request,'admin/category.html')

def addirector(request):
    return render(request,'admin/director.html')

def langaugeMaster(request):
    return render(request,'admin/language_master.html')

def releaseCategory(request):
    return render(request,'admin/release_category.html')

def movieList(request):
    return render(request,'admin/movie_list.html')

def subscriptionDetails(request):
    return render(request,'admin/subscription_details.html')




# director panel

def drindex1(request):
    return render(request,'producer/adindex.html')

def drsignin1(request):
    return render(request,'producer/signin.html')

def drsignup1(request):
    return render(request,'producer/signup.html')

def manageMovies(request):
    return render(request,'producer/manage_movies.html')

def manageTvSeries(request):
    return render(request,'producer/manage_tv_series.html')

def manageEpisodes(request):
    return render(request,'producer/manage_episodes.html')

def paymentDetails(request):
    return render(request,'producer/payment_details.html')




# juwels category 
def adpackage1(request):
    if request.POST['action'] == "getData":
        getData = Package.objects.filter(pack_status="0").values()
        data = list(getData)
        value = JsonResponse(data, safe=False);
        return value;

    elif request.POST['action'] == "add":
        Package.objects.create(
        pack_name = request.POST["selType"],
        pack_price1 = request.POST['txtPrice1'],
        pack_price2 = request.POST['txtPrice2'],
        pack_price3 = request.POST['txtPrice3'],

        
        );
    

    elif request.POST['action'] == "update":
	    Package.objects.filter(
        pack_id = request.POST['id']).update(
        pack_name = request.POST["selType1"],
        pack_price1 = request.POST['txtPrice11'],
        pack_price2 = request.POST['txtPrice21'],
        pack_price3 = request.POST['txtPrice31'],);
        
    elif request.POST['action'] == "delete":
        Package.objects.filter(pack_id=request.POST['id']).update(pack_status='1')
    return HttpResponse();




# juwels category 
def categoryDetails(request):
    if request.POST['action'] == "getData":
        getData = Category.objects.filter(cat_status="0").values()
        data = list(getData)
        value = JsonResponse(data, safe=False);
        return value;

    elif request.POST['action'] == "add":
        Category.objects.create(
        cat_name=request.POST['txtName']);
    

    elif request.POST['action'] == "update":
	    Category.objects.filter(
        cat_id = request.POST['id']).update(
        cat_name = request.POST['txtName1'] );
        
    elif request.POST['action'] == "delete":
        Category.objects.filter(cat_id=request.POST['id']).update(cat_status='1')
    return HttpResponse();


# adding directors


# vendor adding funtion
def addirectorsdetail(request):
    if request.POST['action'] == "getData":
        getData = Directors.objects.filter(Dir_status="0").values()
        data = list(getData)
        value = JsonResponse(data, safe=False);
        return value;
    
    elif request.POST['action'] == "add":
        Directors.objects.create(
        Dir_name = request.POST["txtName"],
        Dir_contact = request.POST["txtcontact"],
        Dir_email = request.POST['txtemail'],
        Dir_place = request.POST["selType"], 
        Dir_password = request.POST["txtPassword"] 

        
        
        );
    
    elif request.POST['action'] == "update":
	    Directors.objects.filter(Dir_id = request.POST['id']).update(
        Dir_name = request.POST["txtName1"],
        Dir_contact = request.POST["txtcontact1"],
        Dir_email = request.POST['txtemail1'],
        Dir_place = request.POST["selType1"] ,
        
        );
    
    elif request.POST['action'] == "delete":
        Directors.objects.filter(Dir_id=request.POST['id']).update(Dir_status ='1')
    return HttpResponse();

def addAdminMaster(request):
	if AdminMaster.objects.filter(ad_email=request.POST['txtEmail'], ad_status='0').exists():
		return HttpResponse("1")
	else:
		AdminMaster.objects.create (
			ad_name = request.POST['txtName'],
			ad_email = request.POST['txtEmail'],
			ad_password = request.POST['txtPassword'],
			ad_phone = request.POST['txtMobileNo'],	
		)

		return HttpResponse(request.POST['txtEmail'])

def getAdminData(request):
    if request.POST['action'] == "getData":
        products_json = AdminMaster.objects.filter(ad_status='0').values()
        data = list(products_json)
        value = JsonResponse(data, safe=False)
        return value

    elif request.POST['action'] == "getData":
        data = AdminMaster.objects.filter(ad_status='0').values()
        data = list(data)
        values = JsonResponse(data, safe=False)
        return values;
    elif request.POST['action'] == "update":
        data = AdminMaster.objects.filter(ad_id=request.POST['id']).update(ad_name = request.POST['txtName1'],ad_email = request.POST['txtEmail1'],ad_phone = request.POST['txtMobileNo1']);
    elif request.POST['action'] == "delete":
        data = AdminMaster.objects.filter(ad_id=request.POST['id']).update(ad_status='1');
    return HttpResponse();

# def updateAdminData(request):
# 	AdminMaster.objects.filter(ad_id = request.POST['id']).update(ad_name = request.POST['txtName1'], ad_mobile = request.POST['txtMobileNo1'], ad_email = request.POST['txtEmail1'])
# 	return HttpResponse()
# 	# pass

# def deleteAdminData(request):

# 	AdminMaster.objects.filter(ad_id = request.POST['id']).update(ad_status = "1")
# 	return HttpResponse()

def adminLoginValidate(request):
    if(request.POST['selRole'] == 'Admin'):
        if AdminMaster.objects.filter(ad_email=request.POST['txtEmail'], ad_password=request.POST['txtPassword'], ad_status='0').exists():
            products_json = AdminMaster.objects.filter(ad_email=request.POST['txtEmail']).values()
            data = list(products_json)
            dictValue = data[0]
            request.session['email'] = dictValue['ad_email']
            request.session['name'] = dictValue['ad_name']
            request.session['phone'] = dictValue['ad_phone']
            return HttpResponse("Admin")
        else:
            return HttpResponse("0")
    else:
        if Directors.objects.filter(Dir_email=request.POST['txtEmail'], Dir_password=request.POST['txtPassword'], Dir_status='0').exists():
            products_json = Directors.objects.filter(Dir_email=request.POST['txtEmail']).values()
            data = list(products_json)
            dictValue = data[0]
            request.session['email'] = dictValue['Dir_email']
            request.session['name'] = dictValue['Dir_name']
            request.session['phone'] = dictValue['Dir_contact']
            return HttpResponse("Producer")
        else:
            return HttpResponse("0")


def languageDetails(request):
    if request.POST['action'] == "add":
        # print("hi")
        Language.objects.create(
            la_name=request.POST['txtName'],
            # ad_role = request.POST['selRole']
        )

    elif request.POST['action'] == "getData":
        data = Language.objects.filter(la_status='0').values()
        data = list(data)
        values = JsonResponse(data, safe=False)
        return values

    elif request.POST['action'] == "update":
        data = Language.objects.filter(la_id=request.POST['id']).update(la_name=request.POST['txtName1'])

    elif request.POST['action'] == "delete":
        data = Language.objects.filter(
            la_id=request.POST['id']).update(la_status='1')

    return HttpResponse()

def manageMoviesDetails(request):
    if request.POST['action'] == "add":
        # print("hi")
        Movie.objects.create(
            mo_language=request.POST['selLangauage'],
            mo_category=request.POST['selCategory'],
            mo_release_category=request.POST['selReleaseCategory'],
            mo_movie_name=request.POST['txtMovieName'],
            mo_movie_description=request.POST['txtMovieDescription'],
            mo_release_year=request.POST['txtReleaseYear'],
            mo_genre=request.POST['txtGenre'],
            mo_country=request.POST['txtCountry'],
            mo_image=request.FILES['lclImage'],
            mo_video=request.POST['txtUploadVideo'],
            mo_created_by = request.session['email']
            # ad_role = request.POST['selRole']
        )

    elif request.POST['action'] == "getData":
        data = Movie.objects.filter(mo_created_by = request.session['email'],mo_status = "0").values()
        data = list(data)
        values = JsonResponse(data, safe=False)
        return values

    elif request.POST['action'] == "update":
        data = Movie.objects.filter(mo_id=request.POST['id']).update(
            mo_language=request.POST['selLangauage1'],
            mo_category=request.POST['selCategory1'],
            mo_release_category=request.POST['selReleaseCategory1'],
            mo_movie_name=request.POST['txtMovieName1'],
            mo_movie_description=request.POST['txtMovieDescription1'],
            mo_release_year=request.POST['txtReleaseYear1'],
            mo_genre=request.POST['txtGenre1'],
            mo_country=request.POST['txtCountry1'])

    elif request.POST['action'] == "delete":
        data = Movie.objects.filter(
            mo_id=request.POST['id']).update(mo_status='1')

    return HttpResponse()

def manageTvSeriesDetails1(request):
    if request.POST['action'] == "add":
        tvSeries.objects.create(
            ts_language=request.POST['selLangauage'],
            ts_category=request.POST['selCategory'],
            ts_release_category=request.POST['selReleaseCategory'],
            ts_seasons=request.POST['txtSeasons'],
            ts_series_name=request.POST['txtSeriesName'],
            ts_created_by = request.session['email']
            # ad_role = request.POST['selRole']
        )

    elif request.POST['action'] == "getData":
        data = tvSeries.objects.filter(ts_created_by = request.session['email'],ts_status = "0").values()
        data = list(data)
        values = JsonResponse(data, safe=False)
        return values

    elif request.POST['action'] == "update":
        data = tvSeries.objects.filter(ts_id=request.POST['id']).update(ts_language=request.POST['selLangauage1'],
            ts_category=request.POST['selCategory1'],
            ts_release_category=request.POST['selReleaseCategory1'],
            ts_seasons=request.POST['txtSeasons1'],
            ts_series_name=request.POST['txtSeriesName1'])

    elif request.POST['action'] == "delete":
        data = tvSeries.objects.filter(
            ts_id=request.POST['id']).update(ts_status='1')

    return HttpResponse('1')


def manageEpisodeDetails(request):
    if request.POST['action'] == "add":
        # print("hi")
        tvEpisodes.objects.create(
            ep_series_name=request.POST['selName'],
            ep_episode_name=request.POST['txtSeasonName'],
            ep_episode_url=request.POST['txtSeasonVideo'],
            ep_created_by = request.session['email']
            # ad_role = request.POST['selRole']
        )

    elif request.POST['action'] == "getData":
        data = tvEpisodes.objects.filter(ep_created_by = request.session['email'],ep_status = "0").values()
        data = list(data)
        values = JsonResponse(data, safe=False)
        return values

    elif request.POST['action'] == "update":
        data = tvEpisodes.objects.filter(ep_id=request.POST['id']).update(ep_series_name=request.POST['selName1'],
            ep_episode_name=request.POST['txtSeasonName1'],
            ep_episode_url=request.POST['txtSeasonVideo1'],)

    elif request.POST['action'] == "delete":
        data = tvEpisodes.objects.filter(
            ep_id=request.POST['id']).update(ep_status='1')

    return HttpResponse()


def getFirstFourItem(request):
    data = Movie.objects.filter(mo_status = "0").values()[:4]
    data = list(data)
    values = JsonResponse(data, safe=False)
    return values

def getNewReleaseItem(request):
    data = Movie.objects.filter(mo_status = "0").values()
    data = list(data)
    values = JsonResponse(data, safe=False)
    return values

def manageTvSeriesDetails(request):
    data = tvSeries.objects.filter(ts_status = "0").values()
    data = list(data)
    values = JsonResponse(data, safe=False)
    return values

def getMovieDetails(request):
    data = Movie.objects.filter(mo_status = "0",mo_id = request.POST['id']).values()
    data = list(data)
    values = JsonResponse(data, safe=False)
    return values

def getPackage(request):
    data = Package.objects.filter(pack_status = 0).values()
    data = list(data)
    values = JsonResponse(data, safe=False)
    return values

def paymentUser(request):
    # print(request.session['user_email'])
    if 'user_email' in request.session:
        # return render(request,'web/pricing.html')
        return HttpResponse('1')
    else:
        # return render(request,'web/signin.html')
        return HttpResponse('0')

def getTvSeries(request):
    data = tvSeries.objects.filter(ts_status = "0").values()
    data = list(data)
    values = JsonResponse(data, safe=False)
    return values

def registerDetails(request):
    if Registration.objects.filter(user_email=request.POST['txtEmail'], user_status='0').exists():
        return HttpResponse("1")
    else:
        lclID = Registration.objects.count()
        status = "0"
        # request.session['email'] = request.POST['txtEmail']
        # request.session['username'] = request.POST['txtName']


        lclNewID = lclID + 1

        Registration.objects.create (
            user_id = lclNewID,
            user_name = request.POST['txtName'],
            user_email = request.POST['txtEmail'],
            user_password = request.POST['txtPassword'],
            user_phone = request.POST['txtMobileNo'],  
            user_status = status,
            # user_created_by = request.session['email']

        )

        return HttpResponse(request.POST['txtEmail'])

def userLoginValidate(request):
    if Registration.objects.filter(user_email=request.POST['txtEmail'], user_password=request.POST['txtPassword'], user_status='0').exists():
        products_json = Registration.objects.filter(user_email=request.POST['txtEmail']).values()
        data = list(products_json)
        dictValue = data[0]
        request.session['user_email'] = dictValue['user_email']
        request.session['user_name'] = dictValue['user_name']
        request.session['user_id'] = dictValue['user_id']



        return HttpResponse(dictValue['user_email']);
    else:
        return HttpResponse("0")

def order(request):
    Order.objects.create (
        or_name = request.session['user_name'],
        or_email = request.session['user_email'],
        or_transaction_id = request.POST['id'],
        or_amount = request.POST['amt'], 
    )
    products_json = Order.objects.filter(or_email=request.session['user_email']).values()
    data = list(products_json)
    dictValue = data[0]
    request.session['or_email'] = dictValue['or_email']

    print(request.POST['remainingDays']);
    api_key = 'aac6730a0dc8a5b7c81cf4c35f650567'
    api_secret = '5f1c7d8729dd7e93b78796ad6ba7697f'
    mailjet = Client(auth=(api_key, api_secret), version='v3.1')
    data = {
    'Messages': [
    {
    "From": {
    "Email": "shaheenkadakol@gmail.com",
    "Name": "OTT PLATFORM"
    },
    "To": [
    {
    "Email": request.session['user_email'],
    "Name": request.session['user_name']
    }
    ],
    "Subject": "Greetings from OTT PLATFORM.",
    "TextPart": "OTT PLATFORM",
    "HTMLPart": "<h3>Dear User, welcome</h3><br /> Thank you for payment,your pack expires in "+request.POST['remainingDays'],
    "CustomID": "AppGettingStartedTest"
    }
    ]
    }
    result = mailjet.send.create(data=data)
    print(result.status_code)
    print(result.json())
    return HttpResponse()


def paySuccess(request):
    return render(request,'web/pay_success.html')

def getTvSeriesDetails(request):
    data = tvSeries.objects.filter(ts_id = request.POST['id'],ts_status = "0").values()
    data = list(data)
    values = JsonResponse(data, safe=False)
    return values

# def getEpisodesDetails(request):
#     data = tvSeries.objects.filter(ts_series_name = request.POST['name'],ts_status = "0").values()
#     data = list(data)
#     values = JsonResponse(data, safe=False)
#     return values



def getEpisodesDetails(request):
    data = tvEpisodes.objects.filter(ep_series_name = request.POST['name'],ep_status = "0").values()
    data = list(data)
    values = JsonResponse(data, safe=False)
    return values

def getEpisodesVideoDetails(request):
    data = tvEpisodes.objects.filter(ep_id = request.POST['id'],ep_status = "0").values()
    data = list(data)
    values = JsonResponse(data, safe=False)
    return values

def Logout(request):
    request.session.delete()
    return render(request,'web/index.html')



def getMovieDetailsAdmin(request):
    data = Movie.objects.filter(mo_status = "0").values()
    data = list(data)
    values = JsonResponse(data, safe=False)
    return values

def getTvSeries(request):
    data = tvSeries.objects.filter(ts_status = "0").values()
    data = list(data)
    values = JsonResponse(data, safe=False)
    return values


def paymentDetailsProducer(request):
    data = Order.objects.filter(or_email = request.session['email'],or_status = "0").values()
    data = list(data)
    values = JsonResponse(data, safe=False)
    return values



def paymentDetailsAdmin(request):
    data = Order.objects.filter(or_status = "0").values()
    data = list(data)
    values = JsonResponse(data, safe=False)
    return values

def getReview(request):
    products_json = Review.objects.filter(rv_movie_name=request.POST['txtMovieName']).values()
    data = list(products_json)
    value = JsonResponse(data, safe=False)
    return value

def submitReview(request):

    lclID = Review.objects.count()
    status = "0"
    lclNewID = lclID + 1

    Review.objects.create (
        rv_id = lclNewID,
        rv_movie_name = request.POST['txtMovieName'],
        rv_name = request.POST['txtName'],
        rv_email = request.POST['txtEmail'],
        rv_message = request.POST['txtMessage'],
        rv_rating = request.POST['selRating'],
        rv_status = status,
    )

    return HttpResponse()


def openSubscriptionProducerDetails(request):
    return render(request,'producer/subscription_details.html')

def paymentDetailsProducer(request):
    data = Order.objects.filter(or_status = "0").values()
    data = list(data)
    values = JsonResponse(data, safe=False)
    return values

def freeMovieDetails1(request):
    return render(request,'web/free_movie_details1.html')

def freeMovieDetails2(request):
    return render(request,'web/free_movie_details2.html')

def freeMovieDetails3(request):
    return render(request,'web/free_movie_details3.html')

def freeMovieDetails4(request):
    return render(request,'web/free_movie_details4.html')

def freeMovieDetails5(request):
    return render(request,'web/free_movie_details5.html')

def freeMovieDetails6(request):
    return render(request,'web/free_movie_details6.html')

def getNewReleaseItemSearch(request):
    data = Movie.objects.filter(mo_movie_name = request.POST['txtSearch'],mo_status = "0").values()
    data = list(data)
    values = JsonResponse(data, safe=False)
    return values

def getTvSeriesSearch(request):
    data = tvSeries.objects.filter(ts_series_name = request.POST['txtSearch'],ts_status = "0").values()
    data = list(data)
    values = JsonResponse(data, safe=False)
    return values