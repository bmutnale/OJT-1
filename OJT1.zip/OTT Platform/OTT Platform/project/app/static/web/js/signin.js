$("#signup").click(function (e) {
    //verification
    if ($("#name").val() == "") {
        alert("Please Enter Name");
        $("#name").focus();
        return false;
    }
 
    if ($("#email").val() == "") {
        alert("Please Enter Mail");
        $("#email").focus();
        return false;
    }

    if ($("#pass").val() == "") {
        alert("Please Enter Password");
        $("#pass").focus();
        return false;
    }





    var formData = new FormData();

    formData.append("name", $("#name").val());
    formData.append("email", $("#email").val());
    formData.append("pass", $("#pass").val());
    formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
    formData.append("action", "add");

    // var table = $("#tableData").DataTable();

    $.ajax({
        url: "/signin_details/",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (result) {
            alert("Directors Details Added");
            location.reload();
        },
        error: function (request, error) {
          console.error (error);
      },
        complete: function () {
            $(".btn .spinner-border").hide();
            $("#btn_add").attr("disabled", false);
        },
    });
});
