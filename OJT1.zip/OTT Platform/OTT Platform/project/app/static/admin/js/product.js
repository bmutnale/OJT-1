

function getData() {

  var formData = new FormData();
  formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
  formData.append("action", "getData");

  $.ajax({

      url: "/product_details/",
      type: "POST",
      data: formData,
      processData: false,
      contentType: false,
      success: function (response) {
        $("#tableData tr:gt(0)").remove();
        for(let i = 0; i < response.length; i++) {
          let j = i + 1;
          let img=response[i].ap_image.substring(3);
          $("#tableData").append('<tr><td>'+j+'</td><td style="display: none;">'+response[i].ap_id+'</td><td><img height="100" width="100" src='+img+'></td><td>'+response[i].ap_type+'</td><td>'+response[i].ap_name+'</td><td>'+response[i].ap_weight+'</td><td>'+response[i].ap_rate+'</td><td>'+response[i].ap_description+'</td><td><div class="d-flex" style="justify-content: space-evenly;">');
        }
      },
      error: function (request, error) {
        console.error(error);
      },
      complete: function () {

      },
    });

}
getData()



