
    function validateEmail(paramEmailID) {
        var filter = /^[0-9a-z.]+\@[a-z0-9]+\.[a-zA-z0-9]{2,4}$/;
        
        if (filter.test(paramEmailID)) {
          return true;
        } else {
          return false;
        }
      }
  
      // alert("Hello");
  
  $("#btn_add").click(function (e) {
    //verification
    if ($("#selLangauage").val().trim().length < 1) {
      alert("Please Select Language");
      $("#selLangauage").focus();
      return false;
    }
  
    if ($("#selCategory").val().trim().length < 1) {
      alert("Please Select Category");
      $("#selCategory").focus();
      return false;
    }
  

    if ($("#selReleaseCategory").val().trim().length < 1) {
      alert("Please Release Category");
      $("#selReleaseCategory").focus();
      return false;
    }

    if ($("#txtMovieName").val().trim().length < 1) {
        alert("Please Enter Movie Name");
        $("#txtMovieName").focus();
        return false;
    }

    if ($("#txtMovieDescription").val().trim().length < 1) {
        alert("Please Enter Movie Description");
        $("#txtMovieDescription").focus();
        return false;
    }

    if ($("#txtReleaseYear").val().trim().length < 1) {
        alert("Please Enter Release Year");
        $("#txtReleaseYear").focus();
        return false;
    }

    if ($("#txtGenre").val().trim().length < 1) {
        alert("Please Enter Genre");
        $("#txtGenre").focus();
        return false;
      }

      if ($("#txtCountry").val().trim().length < 1) {
        alert("Please Enter Country");
        $("#txtCountry").focus();
        return false;
      }


      if ($("#selImage").val().trim().length < 1) {
        alert("Please select image");
        $("#selImage").focus();
        return false;
      }

      if ($("#txtUploadVideo").val().trim().length < 1) {
        alert("Please Enter video url");
        $("#txtUploadVideo").focus();
        return false;
      }

    

    // alert($("#txtEmail").val());

  
   
    var formData = new FormData();

    var lclFile = document.getElementById("selImage");
    lclImage = lclFile.files[0];
    
    formData.append("selLangauage", $("#selLangauage").val());
    formData.append("selCategory", $("#selCategory").val());
    formData.append("selReleaseCategory", $("#selReleaseCategory").val());
    formData.append("txtMovieName", $("#txtMovieName").val());
    formData.append("txtMovieDescription", $("#txtMovieDescription").val());
    formData.append("txtReleaseYear", $("#txtReleaseYear").val());
    formData.append("txtGenre", $("#txtGenre").val());
    formData.append("txtCountry", $("#txtCountry").val());
    formData.append("txtUploadVideo", $("#txtUploadVideo").val());
    formData.append("lclImage",lclImage);


    formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
    formData.append("action", "add");
  
    // var table = $("#dataTables-example").DataTable();
  
    $.ajax({
      beforeSend: function () {
        $(".btn .spinner-border").show();
        $("#btn_add").attr("disabled", true);
      },
      url: "/manage_movies_details/",
      type: "POST",
      // headers: {'X-CSRFToken': '{{ csrf_token }}'},
      data: formData,
      processData: false,
      contentType: false,
      success: function (result) {
  
          alert("Details Added Successfully");
          location.reload();
          table.ajax.reload();
          $("#add_modal").modal('hide');
        
      },
      error: function (request, error) {
        console.error(error);
      },
      complete: function () {
        $(".btn .spinner-border").hide();
        $("#btn_add").attr("disabled", false);
      },
    });
  });
  // var sl_no = 0;
  // ADD Testimnials data Table (DONE)
  $(document).ready(function () {
  
    // $(window).on("load", function () {
      // alert("Hello");
      
    // });
  
   
  
    //Edit modal submit click
    $(document).on("click", "#btn_update", function () {
      // alert("hi");
  
      if ($("#txtName1").val().trim().length < 1) {
        alert("Please Enter Name");
        $("#txtName11").focus();
        return false;
      }
  
      if ($("#txtEmail1").val().trim().length < 1) {
        alert("Please Enter Email");
        $("#txtEmail1").focus();
        return false;
      }
  
      if ($("#txtMobileNo1").val().trim().length < 10) {
        alert("Please Enter Correct Mobile Number");
        $("#txtMobileNo1").focus();
        return false;
      }
  
    
      
      var formData = new FormData()
      formData.append("txtName1", $("#txtName1").val());
      formData.append("txtMobileNo1", $("#txtMobileNo1").val());
      formData.append("txtEmail1", $("#txtEmail1").val());
      formData.append("id", $("#edit_id").val());
      formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
  
      var table = $("#dataTables-example").DataTable();
  
      $.ajax({
        beforeSend: function () {
          $(".btn .spinner-border").show();
          $("#btn_update").attr("disabled", true);
        },
        url: "/update/admin_master/",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (result) {
          alert("Admin Details Updated Succesfully");
          location.reload();
          table.ajax.reload();
          $("#edit_modal").modal('hide');
        },
        error: function (request, error) {
          console.error(error);
        },
        complete: function () {
          $(".btn .spinner-border").hide();
          $("#btn_update").attr("disabled", false);
        },
      });
    });
  
    //Delete work step
    $(document).on("click", "#btn_delete", function () {
  
      var formData = new FormData();
      formData.append("id", $("#delete_id").val());
      formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
  
      // var table = $("#dataTables-example").DataTable();
  
      $.ajax({
        beforeSend: function () {
          $(".btn .spinner-border").show();
        },
  
        url: "/manage_movies_details/",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function () {
          alert("Movies Details deleted succesfully");
          location.reload();
          table.ajax.reload();
          $("#delete_modal").modal('hide');
        },
        error: function (request, error) {
          console.error(error);
        },
        complete: function () {
          $(".btn .spinner-border").hide();
          // Reset Form
          //$("#view_field_form")[0].reset();
          $(".close").click();
        },
      });
    });
  
    $(document).on("click", "#add_user", function () {
  
      $("#txtName").val('');
      $("#txtEmail").val('');
      $("#txtMobileNo").val('');
      $("#txtPassword").val('');
  
    });
  });
  
  // function getAdminData() {
  //   // alert("Hi");
  //   var formData = new FormData();
  //   formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
  //   formData.append("action", "getData");

  
  //   $.ajax({
  
  //       url: "/get_movie_details_admin/",
  //       type: "POST",
  //       data: formData,
  //       processData: false,
  //       contentType: false,
  //       success: function (response) {
  //         console.log(response);
  //         // $("#tableData tr:gt(0)").remove();
  //         for(var i = 0; i < response.length; i++) {
  //           var j = i + 1;
  //           lclImage = response[i].mo_image.substring(3);
  //           $("#tableData").append('<tr> <td>'+j+'</td><td style="display: none;">'+response[i].mo_id+'</td><td>'+response[i].mo_language+'</td><td>'+response[i].mo_category+'</td><td>'+response[i].mo_release_category+'</td><td>'+response[i].mo_movie_name+'</td><td>'+response[i].mo_movie_description+'</td><td>'+response[i].mo_release_year+'</td><td>'+response[i].mo_genre+'</td><td>'+response[i].mo_country+'</td><td><img src="'+lclImage+'" class="img1" width="100px" height="100px"></td><td style="width:100px;height:100px">"'+response[i].mo_video+'"</td><td> <div class="d-flex" style="justify-content: space-evenly;"></div></td></tr>');
  //         }
  //       },
  //       error: function (request, error) {
  //         console.error(error);
  //       },
  //       complete: function () {
  
  //       },
  //     });
  
  // }
  // getAdminData();
 
  



  function getLanguageData() {
    // alert("Hi");
    var formData = new FormData();
    formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
    formData.append("action", "getData");

  
    $.ajax({
  
        url: "/language_details/",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (response) {
            console.log(response);
          // $("#tableData tr:gt(0)").remove();
          for(var i = 0; i < response.length; i++) {
            var j = i + 1;
            $("#selLangauage").append('<option value="'+response[i].la_name+'">'+response[i].la_name+'</option>');
            $("#selLangauage1").append('<option value="'+response[i].la_name+'">'+response[i].la_name+'</option>');

          }
        },
        error: function (request, error) {
          console.error(error);
        },
        complete: function () {
  
        },
      });
  
  }  

  getLanguageData();

  function getCategoryData() {
    // alert("Hi");
    var formData = new FormData();
    formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
    formData.append("action", "getData");

  
    $.ajax({
  
        url: "/adcategory_details/",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (response) {
            console.log(response);
          $("#tableData tr:gt(0)").remove();
          for(var i = 0; i < response.length; i++) {
            var j = i + 1;
            $("#selCategory").append('<option value="'+response[i].cat_name+'">'+response[i].cat_name+'</option>');
            $("#selCategory1").append('<option value="'+response[i].cat_name+'">'+response[i].cat_name+'</option>');

          }
        },
        error: function (request, error) {
          console.error(error);
        },
        complete: function () {
  
        },
      });
  
  }  

  getCategoryData();

   function getRowsUpdate() {
    $("#tableData tr").click(function() {
        var currentRow = $(this).closest("tr");
        var lclID = currentRow.find("td:eq(1)").text();
        var lclName = currentRow.find("td:eq(2)").text();
        var lclEmail = currentRow.find("td:eq(3)").text();
        var lclMobile = currentRow.find("td:eq(4)").text();
        var lclMobile1 = currentRow.find("td:eq(5)").text();
        var lclMobile2 = currentRow.find("td:eq(6)").text();
        var lclMobile3 = currentRow.find("td:eq(7)").text();
        var lclMobile4 = currentRow.find("td:eq(8)").text();
        var lclMobile5 = currentRow.find("td:eq(9)").text();



  
        // alert(lclName);
        $("#selLangauage1").val(lclName);
        $("#selCategory1").val(lclEmail);
        $("#selReleaseCategory1").val(lclMobile);
        $("#txtMovieName1").val(lclMobile1);
        $("#txtMovieDescription1").val(lclMobile2);   
        $("#txtReleaseYear1").val(lclMobile3);   
        $("#txtGenre1").val(lclMobile4);   
        $("#txtCountry1").val(lclMobile5);   


        $("#edit_id").val(lclID);
  
    });
  }
  
  
  function getRowsDelete() {
    $("#tableData tr").click(function() {
        var currentRow = $(this).closest("tr");
        var lclID = currentRow.find("td:eq(1)").text();
        
        $("#delete_id").val(lclID);
  
    });

    // alert("H");
  }