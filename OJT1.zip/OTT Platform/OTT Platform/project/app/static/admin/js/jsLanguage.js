// category table

  function alphaOnly(event) {
      var key = event.which ? event.which : event.keyCode;
      return (
        (key >= 65 && key <= 90) ||
        key == 8 ||
        (event.charCode >= 97 && event.charCode <= 122) ||
        event.charCode == 32
      );
    }


$("#btn_add").click(function (e) {


    if ($("#txtName").val() == "") {
        alert("Please Enter Language Name");
        $("#txtName").focus();
        return false;
    }




    let formData = new FormData();
    formData.append("txtName", $("#txtName").val());


    // formData.append("filePhoto", $("#filePhoto").val());
    formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
    formData.append("action", "add");

    $.ajax({
        url: "/language_details/",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (result) {
            alert(" Details Added");
            location.reload();
        },
        error: function (request, error) {
            console.error(error);
        },
        complete: function () {
            $(".btn .spinner-border").hide();
            $("#btn_add").attr("disabled", false);
        },
    });

});

// data table creation
// $("#create").click(function (e)){
function getData() {

    let formData = new FormData();
    formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
    formData.append("action", "getData");

    $.ajax({
        url: "/language_details/",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (response) {
            console.log(response);

            for (let i = 0; i < response.length; i++) {
                let j = i + 1;
                // let img = response[i].cat_image.substring(3);
                $("#tableData").append('<tr><td class="text-center align-center">' + j +
                    '</td><td style="display: none;" class="text-center">' + response[i].la_id+
                    '</td><td class="text-center">' + response[i].la_name+
                    '</td><td><div class="d-flex" style="justify-content: space-evenly;"><a href="javascript:void(0);" id="edit_row" title="View/Edit" data-bs-toggle="modal" data-bs-target="#edit_modal" class="text-primary" onClick="getRowsUpdate();"> <i class="fas fa-pen"></i></a><a href="javascript:void(0);" title="Delete" data-bs-toggle="modal" data-bs-target="#delete_modal" class="text-danger" id="delete_row" onClick="getRowsDelete();"> <i class="far fa-trash-alt"></i></a></div></td></tr>');
            }

            // $("#tableData").append('<tr></tr>');

        },
        error: function (request, error) {
            console.error(error);
        },
        complete: function () {
            $(".btn .spinner-border").hide();
            $("#btn_add").attr("disabled", false);
        },
    });
}
getData()


// update

$("#btn_update").click(function (e) {

    if ($("#txtName1").val() == "") {
        alert("Please Enter Price");
        $("#txtName2").focus();
        return false;
    }



    let formData = new FormData();
    formData.append("txtName1", $("#txtName1").val());
    formData.append("id", $("#edit_id").val());
    formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
    formData.append("action", "update");

    $.ajax({
        url: "/language_details/",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (result) {
            alert("Details Updated");
            location.reload();
        },
        error: function (request, error) {
            console.error(error);
        },
        complete: function () {
            $(".btn .spinner-border").hide();
            $("#btn_add").attr("disabled", false);
        },
    });

});


// Update()


function getRowsUpdate() {
    $("#tableData tr").click(function () {
        var currentRow = $(this).closest("tr");
        var lclID = currentRow.find("td:eq(1)").text();
        var lclName = currentRow.find("td:eq(2)").text();
        // alert(lclName);
        $("#txtName1").val(lclName);
        // $("#filePhoto1").val(filePhoto1);
        $("#edit_id").val(lclID);
        $('#edit_modal').modal('show');

    });
}



//delete data

function getRowsDelete() {
    $("#tableData tr").click(function () {
        var currentRow = $(this).closest("tr");
        var lclID = currentRow.find("td:eq(1)").text();
        // alert(lclID);
        $("#delete_id").val(lclID);
        $('#delete_modal').modal('show');


    });
}


$(document).on("click", "#btn_delete", function () {

    let formData = new FormData();
    formData.append("id", $("#delete_id").val());
    formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
    formData.append("action", "delete");

    // var table = $("#tableData").DataTable();

    $.ajax({
        beforeSend: function () {
            $(".btn .spinner-border").show();
        },

        url: "/language_details/",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function () {
            alert("Details deleted succesfully");
            location.reload();
            table.ajax.reload();
            $("#delete_modal").modal('hide');
        },
        error: function (request, error) {
            console.error(error);
        },
        complete: function () {
            $(".btn .spinner-border").hide();
            $(".close").click();
        },
    });
});





