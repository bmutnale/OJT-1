// category table

$("#create").click(function (e) {


    if ($("#selType").val() == "") {
        alert("Please Select Package Type");
        $("#selType").focus();
        return false;
    }

    if ($("#txtPrice1").val() == "") {
        alert("Please Enter Price for 3 months");
        $("#txtPrice1").focus();
        return false;
    }

    if ($("#txtPrice2").val() == "") {
        alert("Please Enter Price  for 6 months");
        $("#txtPrice2").focus();
        return false;
    }

    if ($("#txtPrice3").val() == "") {
        alert("Please Enter Price  for 12 months");
        $("#txtPrice3").focus();
        return false;
    }

    let formData = new FormData();
    formData.append("selType", $("#selType").val());
    formData.append("txtPrice1", $("#txtPrice1").val());
    formData.append("txtPrice2", $("#txtPrice2").val());
    formData.append("txtPrice3", $("#txtPrice3").val());


    // formData.append("filePhoto", $("#filePhoto").val());
    formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
    formData.append("action", "add");

    $.ajax({
        url: "/adpackage_details/",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (result) {
            alert("Package Details Added");
            location.reload();
        },
        error: function (request, error) {
            console.error(error);
        },
        complete: function () {
            $(".btn .spinner-border").hide();
            $("#btn_add").attr("disabled", false);
        },
    });

});

// data table creation
// $("#create").click(function (e)){
function getData() {

    let formData = new FormData();
    formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
    formData.append("action", "getData");

    $.ajax({
        url: "/adpackage_details/",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (response) {
            console.log(response);

            for (let i = 0; i < response.length; i++) {
                let j = i + 1;
                // let img = response[i].cat_image.substring(3);
                $("#tableData").append('<tr><td class="text-center align-center">' + j +
                    '</td><td style="display: none;" class="text-center">' + response[i].pack_id +
                    '</td><td class="text-center">' + response[i].pack_name +
                    '</td><td class="text-center">' + "Rs." + response[i].pack_price1 + '</td><td class="text-center">' + "Rs." + response[i].pack_price2 + '</td><td class="text-center">' + "Rs." + response[i].pack_price3 + '</td><td><div class="d-flex" style="justify-content: space-evenly;"><a href="javascript:void(0);" id="edit_row" title="View/Edit" data-bs-toggle="modal" data-bs-target="#edit_modal" class="text-primary" onClick="getRowsUpdate();"> <i class="fas fa-pen"></i></a><a href="javascript:void(0);" title="Delete" data-bs-toggle="modal" data-bs-target="#delete_modal" class="text-danger" id="delete_row" onClick="getRowsDelete();"> <i class="far fa-trash-alt"></i></a></div></td></tr>');
            }

            // $("#tableData").append('<tr></tr>');

        },
        error: function (request, error) {
            console.error(error);
        },
        complete: function () {
            $(".btn .spinner-border").hide();
            $("#btn_add").attr("disabled", false);
        },
    });
}
getData()


// update

$("#update").click(function (e) {

    if ($("#selType1").val() == "") {
        alert("Please Select Package Type");
        $("#selType1").focus();
        return false;
    }

    if ($("#txtPrice11").val() == "") {
        alert("Please Enter Price for 3 months");
        $("#txtPrice11").focus();
        return false;
    }

    if ($("#txtPrice21").val() == "") {
        alert("Please Enter Price  for 6 months");
        $("#txtPrice21").focus();
        return false;
    }

    if ($("#txtPrice31").val() == "") {
        alert("Please Enter Price  for 12 months");
        $("#txtPrice31").focus();
        return false;
    }

    let formData = new FormData();
    formData.append("selType1", $("#selType1").val());
    formData.append("txtPrice11", $("#txtPrice11").val());
    formData.append("txtPrice21", $("#txtPrice21").val());
    formData.append("txtPrice31", $("#txtPrice31").val());
    formData.append("id", $("#edit_id").val());
    formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
    formData.append("action", "update");

    $.ajax({
        url: "/adpackage_details/",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (result) {
            alert("Package Updated");
            location.reload();
        },
        error: function (request, error) {
            console.error(error);
        },
        complete: function () {
            $(".btn .spinner-border").hide();
            $("#btn_add").attr("disabled", false);
        },
    });

});


// Update()


function getRowsUpdate() {
    $("#tableData tr").click(function () {
        var currentRow = $(this).closest("tr");
        var lclID = currentRow.find("td:eq(1)").text();
        var lclName = currentRow.find("td:eq(2)").text();
        var lclPrice1 = currentRow.find("td:eq(3)").text();
        var lclPrice2 = currentRow.find("td:eq(4)").text();
        var lclPrice3 = currentRow.find("td:eq(5)").text();

        // alert(lclName);
        $("#selType1").val(lclName);
        $("#txtPrice11").val(lclPrice1);
        $("#txtPrice21").val(lclPrice2);
        $("#txtPrice31").val(lclPrice3);


        // $("#filePhoto1").val(filePhoto1);
        $("#edit_id").val(lclID);
        $('#edit_modal').modal('show');

    });
}



//delete data

function getRowsDelete() {
    $("#tableData tr").click(function () {
        var currentRow = $(this).closest("tr");
        var lclID = currentRow.find("td:eq(1)").text();
        // alert(lclID);
        $("#delete_id").val(lclID);
        $('#delete_modal').modal('show');


    });
}


$(document).on("click", "#btn_delete", function () {

    let formData = new FormData();
    formData.append("id", $("#delete_id").val());
    formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
    formData.append("action", "delete");

    // var table = $("#tableData").DataTable();

    $.ajax({
        beforeSend: function () {
            $(".btn .spinner-border").show();
        },

        url: "/adpackage_details/",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function () {
            alert("Product deleted succesfully");
            location.reload();
            table.ajax.reload();
            $("#delete_modal").modal('hide');
        },
        error: function (request, error) {
            console.error(error);
        },
        complete: function () {
            $(".btn .spinner-border").hide();
            $(".close").click();
        },
    });
});





