function getData() {

    let formData = new FormData();
    formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
    formData.append("action", "getData");

    $.ajax({
        url: "/payment_details_producer/",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (response) {
            console.log(response);

            for (let i = 0; i < response.length; i++) {
                let j = i + 1;
                // let img = response[i].cat_image.substring(3);
                // alert(response[i].or_amount);
                let amount = parseInt(response[i].or_amount)/2;
                // alert(amount);
                $("#tableData").append('<tr><td class="text-center align-center">' + j +
                    '</td><td style="display: none;" class="text-center">' + response[i].or_id+
                    '</td><td class="text-center">' + response[i].or_name+
                    '</td><td class="text-center">' + response[i].or_email+
                    '</td><td class="text-center">' + response[i].or_amount+
                    '</td><td class="text-center">' + amount+
                    '</td><td class="text-center">' + response[i].or_transaction_id+
                    '</td></tr>');
            }

            // $("#tableData").append('<tr></tr>');

        },
        error: function (request, error) {
            console.error(error);
        },
        complete: function () {
            $(".btn .spinner-border").hide();
            $("#btn_add").attr("disabled", false);
        },
    });
}
getData()