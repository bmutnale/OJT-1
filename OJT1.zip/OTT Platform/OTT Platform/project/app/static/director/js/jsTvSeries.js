function getLanguageData() {
    // alert("Hi");
    var formData = new FormData();
    formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
    formData.append("action", "getData");

  
    $.ajax({
  
        url: "/language_details/",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (response) {
            console.log(response);
          $("#tableData tr:gt(0)").remove();
          for(var i = 0; i < response.length; i++) {
            var j = i + 1;
            $("#selLangauage").append('<option value="'+response[i].la_name+'">'+response[i].la_name+'</option>');
            $("#selLangauage1").append('<option value="'+response[i].la_name+'">'+response[i].la_name+'</option>');
            
          }
        },
        error: function (request, error) {
          console.error(error);
        },
        complete: function () {
  
        },
      });
  
  } 

  getLanguageData();

  function getCategoryData() {
    // alert("Hi");
    var formData = new FormData();
    formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
    formData.append("action", "getData");

  
    $.ajax({
  
        url: "/adcategory_details/",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (response) {
            console.log(response);
          $("#tableData tr:gt(0)").remove();
          for(var i = 0; i < response.length; i++) {
            var j = i + 1;
            $("#selCategory").append('<option value="'+response[i].cat_name+'">'+response[i].cat_name+'</option>');
            $("#selCategory1").append('<option value="'+response[i].cat_name+'">'+response[i].cat_name+'</option>');
            
          }
        },
        error: function (request, error) {
          console.error(error);
        },
        complete: function () {
  
        },
      });
  
  }  

  getCategoryData();

  
  function validateEmail(paramEmailID) {
    var filter = /^[0-9a-z.]+\@[a-z0-9]+\.[a-zA-z0-9]{2,4}$/;
    
    if (filter.test(paramEmailID)) {
      return true;
    } else {
      return false;
    }
  }

  // alert("Hello");

$("#btn_add").click(function (e) {
//verification
if ($("#selLangauage").val().trim().length < 1) {
  alert("Please Select Language");
  $("#selLangauage").focus();
  return false;
}

if ($("#selCategory").val().trim().length < 1) {
  alert("Please Select Category");
  $("#selCategory").focus();
  return false;
}


if ($("#selReleaseCategory").val().trim().length < 1) {
  alert("Please Release Category");
  $("#selReleaseCategory").focus();
  return false;
}

if ($("#txtSeasons").val().trim().length < 1) {
    alert("Please Enter Seasons");
    $("#txtSeasons").focus();
    return false;
}

if ($("#txtSeriesName").val().trim().length < 1) {
    alert("Please Series Name");
    $("#txtSeriesName").focus();
    return false;
}




// alert($("#txtEmail").val());



var formData = new FormData();




formData.append("selLangauage", $("#selLangauage").val());
formData.append("selCategory", $("#selCategory").val());
formData.append("selReleaseCategory", $("#selReleaseCategory").val());
formData.append("txtSeasons", $("#txtSeasons").val());
formData.append("txtSeriesName", $("#txtSeriesName").val());

formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
formData.append("action", "add");

// var table = $("#dataTables-example").DataTable();

$.ajax({
  beforeSend: function () {
    $(".btn .spinner-border").show();
    $("#btn_add").attr("disabled", true);
  },
  url: "/manage_tvSeries_details/",
  type: "POST",
  // headers: {'X-CSRFToken': '{{ csrf_token }}'},
  data: formData,
  processData: false,
  contentType: false,
  success: function (result) {
    // alert(result);
      alert("Details Added Successfully");
      location.reload();
      // table.ajax.reload();
      $("#add_modal").modal('hide');
    
  },
  error: function (request, error) {
    console.error(error);
  },
  complete: function () {
    $(".btn .spinner-border").hide();
    $("#btn_add").attr("disabled", false);
  },
});
});

 $(document).on("click", "#btn_update", function () {
      // alert("hi");
  if ($("#selLangauage1").val().trim().length < 1) {
  alert("Please Select Language");
  $("#selLangauage1").focus();
  return false;
}

if ($("#selCategory1").val().trim().length < 1) {
  alert("Please Select Category");
  $("#selCategory1").focus();
  return false;
}


if ($("#selReleaseCategory1").val().trim().length < 1) {
  alert("Please Release Category");
  $("#selReleaseCategory1").focus();
  return false;
}

if ($("#txtSeasons1").val().trim().length < 1) {
    alert("Please Enter Seasons");
    $("#txtSeasons1").focus();
    return false;
}

if ($("#txtSeriesName1").val().trim().length < 1) {
    alert("Please Series Name");
    $("#txtSeriesName1").focus();
    return false;
}




// alert($("#txtEmail").val());



var formData = new FormData();



      formData.append("selLangauage1", $("#selLangauage1").val());
      formData.append("selCategory1", $("#selCategory1").val());
      formData.append("selReleaseCategory1", $("#selReleaseCategory1").val());
      formData.append("txtSeasons1", $("#txtSeasons1").val());
      formData.append("txtSeriesName1", $("#txtSeriesName1").val());
      formData.append("id", $("#edit_id").val());
      formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
      formData.append("action", "update");

  
      // var table = $("#dataTables-example").DataTable();
  
      $.ajax({
        beforeSend: function () {
          $(".btn .spinner-border").show();
          $("#btn_update").attr("disabled", true);
        },
        url: "/manage_tvSeries_details/",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (result) {
          alert(" Details Updated Succesfully");
          location.reload();
          table.ajax.reload();
          $("#edit_modal").modal('hide');
        },
        error: function (request, error) {
          console.error(error);
        },
        complete: function () {
          $(".btn .spinner-border").hide();
          $("#btn_update").attr("disabled", false);
        },
      });
    });

     $(document).on("click", "#btn_delete", function () {
  
      var formData = new FormData();
      formData.append("id", $("#delete_id").val());
      formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
      formData.append("action", "delete");

  
      // var table = $("#dataTables-example").DataTable();
  
      $.ajax({
        beforeSend: function () {
          $(".btn .spinner-border").show();
        },
  
        url: "/manage_tvSeries_details/",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function () {
          alert("Details deleted succesfully");
          location.reload();
          table.ajax.reload();
          $("#delete_modal").modal('hide');
        },
        error: function (request, error) {
          console.error(error);
        },
        complete: function () {
          $(".btn .spinner-border").hide();
          // Reset Form
          //$("#view_field_form")[0].reset();
          $(".close").click();
        },
      });
    });

  function getAdminData() {
    // alert("Hi");
    var formData = new FormData();
    formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
    formData.append("action", "getData");

  
    $.ajax({
  
        url: "/manage_tvSeries_details/",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (response) {
          console.log(response);
          $("#tableData tr:gt(0)").remove();
          for(var i = 0; i < response.length; i++) {
            var j = i + 1;
            // lclImage = response[i].mo_image.substring(3);
            $("#tableData").append('<tr><td>'+j+'</td><td style="display: none;">'+response[i].ts_id+'</td><td>'+response[i].ts_language+'</td><td>'+response[i].ts_category+'</td><td>'+response[i].ts_release_category+'</td><td>'+response[i].ts_seasons+'</td><td>'+response[i].ts_series_name+'</td><td><div class="d-flex" style="justify-content: space-evenly;"><a href="javascript:void(0);" id="edit_row" title="View/Edit"  data-bs-toggle="modal" data-bs-target="#edit_modal" class="text-primary" onClick="getRowsUpdate();">Edit</a><a href="javascript:void(0);" title="Delete" data-bs-toggle="modal" data-bs-target="#delete_modal" class="text-danger" id="delete_row" onClick="getRowsDelete();">Delete</a></div></td></tr>');
          }
        },
        error: function (request, error) {
          console.error(error);
        },
        complete: function () {
  
        },
      });
  
  }
  getAdminData();

   function getRowsUpdate() {
    $("#tableData tr").click(function() {
        var currentRow = $(this).closest("tr");
        var lclID = currentRow.find("td:eq(1)").text();
        var lclName = currentRow.find("td:eq(2)").text();
        var lclEmail = currentRow.find("td:eq(3)").text();
        var lclMobile = currentRow.find("td:eq(4)").text();
        var lclMobile1 = currentRow.find("td:eq(5)").text();
        var lclMobile2 = currentRow.find("td:eq(6)").text();


  
        // alert(lclName);
        $("#selLangauage1").val(lclName);
        $("#selCategory1").val(lclEmail);
        $("#selReleaseCategory1").val(lclMobile);
        $("#txtSeasons1").val(lclMobile1);
        $("#txtSeriesName1").val(lclMobile2);   
        $("#edit_id").val(lclID);
  
    });
  }
  
  
  function getRowsDelete() {
    $("#tableData tr").click(function() {
        var currentRow = $(this).closest("tr");
        var lclID = currentRow.find("td:eq(1)").text();
        
        $("#delete_id").val(lclID);
  
    });

    // alert("H");
  }