function getSeasonData() {
    // alert("Hi");
    var formData = new FormData();
    formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
    formData.append("action", "getData");

  
    $.ajax({
  
        url: "/manage_tvSeries_details/",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (response) {
            console.log(response);
          $("#tableData tr:gt(0)").remove();
          for(var i = 0; i < response.length; i++) {
            var j = i + 1;
            $("#selName").append('<option value="'+response[i].ts_series_name+'">'+response[i].ts_series_name+'</option>');
            $("#selName1").append('<option value="'+response[i].ts_series_name+'">'+response[i].ts_series_name+'</option>');
            
          }
        },
        error: function (request, error) {
          console.error(error);
        },
        complete: function () {
  
        },
      });
  
  } 
getSeasonData();
$("#btn_add").click(function (e) {
//verification
if ($("#selName").val().trim().length < 1) {
  alert("Please Select Series Name");
  $("#selName").focus();
  return false;
}

if ($("#txtSeasonName").val().trim().length < 1) {
  alert("Please Season Name");
  $("#txtSeasonName").focus();
  return false;
}


if ($("#txtSeasonVideo").val().trim().length < 1) {
  alert("Please Enter Video URL");
  $("#txtSeasonVideo").focus();
  return false;
}





// alert($("#txtEmail").val());



var formData = new FormData();



formData.append("selName", $("#selName").val());
formData.append("txtSeasonName", $("#txtSeasonName").val());
formData.append("txtSeasonVideo", $("#txtSeasonVideo").val());

formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
formData.append("action", "add");

// var table = $("#dataTables-example").DataTable();

$.ajax({
  beforeSend: function () {
    $(".btn .spinner-border").show();
    $("#btn_add").attr("disabled", true);
  },
  url: "/manage_episode_details/",
  type: "POST",
  // headers: {'X-CSRFToken': '{{ csrf_token }}'},
  data: formData,
  processData: false,
  contentType: false,
  success: function (result) {

      alert("Details Added Successfully");
      location.reload();
      table.ajax.reload();
      $("#add_modal").modal('hide');
    
  },
  error: function (request, error) {
    console.error(error);
  },
  complete: function () {
    $(".btn .spinner-border").hide();
    $("#btn_add").attr("disabled", false);
  },
});
});
 $(document).on("click", "#btn_update", function () {
      // alert("hi");
  

    if ($("#selName1").val().trim().length < 1) {
      alert("Please Select Series Name");
      $("#selName1").focus();
      return false;
    }

    if ($("#txtSeasonName1").val().trim().length < 1) {
      alert("Please Season Name");
      $("#txtSeasonName1").focus();
      return false;
    }


    if ($("#txtSeasonVideo1").val().trim().length < 1) {
      alert("Please Enter Video URL");
      $("#txtSeasonVideo1").focus();
      return false;
    }





    // alert($("#txtEmail").val());



    var formData = new FormData();



    formData.append("selName1", $("#selName1").val());
    formData.append("txtSeasonName1", $("#txtSeasonName1").val());
    formData.append("txtSeasonVideo1", $("#txtSeasonVideo1").val());
      formData.append("id", $("#edit_id").val());
      formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
      formData.append("action", "update");

  
      // var table = $("#dataTables-example").DataTable();
  
      $.ajax({
        beforeSend: function () {
          $(".btn .spinner-border").show();
          $("#btn_update").attr("disabled", true);
        },
        url: "/manage_episode_details/",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (result) {
          alert(" Details Updated Succesfully");
          location.reload();
          table.ajax.reload();
          $("#edit_modal").modal('hide');
        },
        error: function (request, error) {
          console.error(error);
        },
        complete: function () {
          $(".btn .spinner-border").hide();
          $("#btn_update").attr("disabled", false);
        },
      });
    });

     $(document).on("click", "#btn_delete", function () {
  
      var formData = new FormData();
      formData.append("id", $("#delete_id").val());
      formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
      formData.append("action", "delete");

  
      // var table = $("#dataTables-example").DataTable();
  
      $.ajax({
        beforeSend: function () {
          $(".btn .spinner-border").show();
        },
  
        url: "/manage_episode_details/",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function () {
          alert("Details deleted succesfully");
          location.reload();
          table.ajax.reload();
          $("#delete_modal").modal('hide');
        },
        error: function (request, error) {
          console.error(error);
        },
        complete: function () {
          $(".btn .spinner-border").hide();
          // Reset Form
          //$("#view_field_form")[0].reset();
          $(".close").click();
        },
      });
    });
  function getAdminData() {
    // alert("Hi");
    var formData = new FormData();
    formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
    formData.append("action", "getData");

  
    $.ajax({
  
        url: "/manage_episode_details/",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (response) {
          console.log(response);
          $("#tableData tr:gt(0)").remove();
          for(var i = 0; i < response.length; i++) {
            var j = i + 1;
            // lclImage = response[i].mo_image.substring(3);
            $("#tableData").append('<tr><td>'+j+'</td><td style="display: none;">'+response[i].ep_id+'</td><td>'+response[i].ep_series_name+'</td><td>'+response[i].ep_episode_name+'</td><td>'+response[i].ep_episode_url+'</td><td><div class="d-flex" style="justify-content: space-evenly;"><a href="javascript:void(0);" id="edit_row" title="View/Edit"  data-bs-toggle="modal" data-bs-target="#edit_modal" class="text-primary" onClick="getRowsUpdate();">Edit</a><a href="javascript:void(0);" title="Delete" data-bs-toggle="modal" data-bs-target="#delete_modal" class="text-danger" id="delete_row" onClick="getRowsDelete();">Delete</a></div></td></tr>');
          }
        },
        error: function (request, error) {
          console.error(error);
        },
        complete: function () {
  
        },
      });
  
  }
  getAdminData();

   function getRowsUpdate() {
    $("#tableData tr").click(function() {
        var currentRow = $(this).closest("tr");
        var lclID = currentRow.find("td:eq(1)").text();
        var lclName = currentRow.find("td:eq(2)").text();
        var lclEmail = currentRow.find("td:eq(3)").text();
        var lclMobile = currentRow.find("td:eq(4)").text();

        // alert(lclName);
        $("#selName1").val(lclName);
        $("#txtSeasonName1").val(lclEmail);
        $("#txtSeasonVideo1").val(lclMobile);
        $("#edit_id").val(lclID);
  
    });
  }
  
  
  function getRowsDelete() {
    $("#tableData tr").click(function() {
        var currentRow = $(this).closest("tr");
        var lclID = currentRow.find("td:eq(1)").text();
        // alert(lclID);
        $("#delete_id").val(lclID);
  
    });
  }