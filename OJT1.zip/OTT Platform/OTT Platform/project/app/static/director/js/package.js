// data table creation
// $("#create").click(function (e)){
    function getData() {

        let formData = new FormData();
        formData.append("csrfmiddlewaretoken", $('input[name=csrfmiddlewaretoken]').val());
        formData.append("action", "getData");
    
        $.ajax({
            url: "/adpackage_details/",
            type: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function (response) {
                console.log(response);
    
                for (let i = 0; i < response.length; i++) {
                    let j = i + 1;
                    // let img = response[i].cat_image.substring(3);
                    $("#tableData").append('<tr><td class="text-center align-center">' + j +
                        '</td><td style="display: none;" class="text-center">' + response[i].pack_id +
                        '</td><td class="text-center">' + response[i].pack_name +
                        '</td><td class="text-center">' + "Rs." + response[i].pack_price + '</td><td><div class="d-flex" style="justify-content: space-evenly;"></tr>');
                }
    
                // $("#tableData").append('<tr></tr>');
    
            },
            error: function (request, error) {
                console.error(error);
            },
            complete: function () {
                $(".btn .spinner-border").hide();
                $("#btn_add").attr("disabled", false);
            },
        });
    }
    getData()
    