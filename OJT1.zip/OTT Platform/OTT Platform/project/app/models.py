from django.db import models
from msilib import add_tables

# Create your models here.


class Package(models.Model):
    pack_id = models.AutoField(primary_key=True, unique=True)
    pack_name = models.CharField(max_length=100)
    pack_price1 = models.CharField(max_length=100,default="")
    pack_price2 = models.CharField(max_length=100,default="")
    pack_price3 = models.CharField(max_length=100,default="")
    pack_status = models.CharField(max_length=100, default=0)


class Category(models.Model):
    cat_id = models.AutoField(primary_key=True, unique=True)
    cat_name = models.CharField(max_length=100)
    cat_status = models.CharField(max_length=100, default=0)

class Directors(models.Model):
	Dir_id = models.AutoField(primary_key=True, unique = True)
	Dir_name = models.CharField(max_length=80)
	Dir_contact = models.CharField(max_length=80)
	Dir_email = models.CharField(max_length=80 )
	Dir_password = models.CharField(max_length=80,default="")
	Dir_place = models.CharField(max_length=80)
	Dir_status = models.CharField(max_length=80, default="0")

class AdminMaster(models.Model):
    ad_id = models.AutoField(primary_key=True, unique = True)
    ad_name = models.CharField(max_length=80)
    ad_email = models.CharField(max_length=80 )
    ad_phone = models.CharField(max_length=80)
    ad_password = models.CharField(max_length=80)
    ad_status  = models.IntegerField(default="0")
    ad_created_by = models.CharField(max_length=100)


class Language(models.Model):
    la_id = models.AutoField(primary_key=True, unique=True)
    la_name = models.CharField(max_length=100)
    la_status = models.CharField(max_length=100, default=0)

class ReleaseCategory(models.Model):
    rc_id = models.AutoField(primary_key=True, unique=True)
    rc_name = models.CharField(max_length=100)
    rc_status = models.CharField(max_length=100, default=0)

class Movie(models.Model):
    mo_id = models.AutoField(primary_key=True, unique = True)
    mo_language = models.CharField(max_length=80)
    mo_category = models.CharField(max_length=80 )
    mo_release_category = models.CharField(max_length=80)
    mo_movie_name = models.CharField(max_length=80)
    mo_movie_description = models.CharField(max_length=80)
    mo_release_year = models.CharField(max_length=80)
    mo_genre = models.CharField(max_length=80)
    mo_country = models.CharField(max_length=80)
    mo_image = models.ImageField(upload_to="app/static/media/movie/" ,default="True")
    mo_video = models.TextField(default="0")
    mo_price = models.CharField(max_length=80)
    mo_revenue = models.CharField(max_length=80)
    mo_status  = models.IntegerField(default="0")
    mo_created_by = models.CharField(max_length=100)

class tvSeries(models.Model):
    ts_id = models.AutoField(primary_key=True, unique = True)
    ts_language = models.CharField(max_length=80)
    ts_category = models.CharField(max_length=80 )
    ts_release_category = models.CharField(max_length=80)
    ts_seasons = models.CharField(max_length=80)
    ts_series_name = models.CharField(max_length=80)
    ts_status  = models.IntegerField(default="0")
    ts_created_by = models.CharField(max_length=100)

class tvEpisodes(models.Model):
    ep_id = models.AutoField(primary_key=True, unique = True)
    ep_series_name = models.CharField(max_length=80)
    ep_episode_name = models.CharField(max_length=80 )
    ep_episode_url = models.TextField(default="0")
    ep_status  = models.IntegerField(default="0")
    ep_created_by = models.CharField(max_length=100)

class subscription(models.Model):
    su_id = models.AutoField(primary_key=True, unique = True)
    su_name = models.CharField(max_length=80)
    su_amount = models.CharField(max_length=80 )
    su_package_name = models.CharField(max_length=80)
    su_phone = models.CharField(max_length=80)
    su_email = models.CharField(max_length=80)
    su_status  = models.IntegerField(default="0")
    su_created_by = models.CharField(max_length=100)


class Registration(models.Model):
    user_id = models.AutoField(primary_key=True, unique = True)
    user_name = models.CharField(max_length=100)
    user_email = models.CharField(max_length=100)
    user_password = models.CharField(max_length=100)
    user_phone = models.CharField(max_length=100)
    user_location = models.CharField(max_length=100)
    user_zipcode = models.CharField(max_length=100)
    user_status = models.CharField(max_length=100)
    user_created_by = models.CharField(max_length=100)

class Order(models.Model):
    or_id = models.AutoField(primary_key=True, unique = True)
    or_name = models.CharField(max_length=100)
    or_email = models.CharField(max_length=100)
    or_transaction_id = models.CharField(max_length=100)
    or_amount = models.CharField(max_length=10)
    or_status  = models.IntegerField(default="0")
    or_created_by = models.CharField(max_length=100)

class Review(models.Model):
    rv_id = models.AutoField(primary_key=True, unique = True)
    rv_movie_name = models.CharField(max_length=100)
    rv_name = models.CharField(max_length=100)
    rv_email = models.CharField(max_length=100)
    rv_message = models.CharField(max_length=100)
    rv_rating = models.CharField(max_length=100)
    rv_status = models.CharField(max_length=100)

	
