from atexit import register
from app import views
from django.contrib import admin
from django.urls import path


urlpatterns = [
    # path('admin/', admin.site.urls),


    # web templates with user modal
    path("about/", views.aboutweb, name='about'),

    path("catalog1/", views.catalog1, name='catalog1'),

    path("catalog2/", views.catalog2, name='catalog2'),

    path("details1/", views.details1, name='details1'),

    path("details2/", views.details2, name='details2'),

    path("faq/", views.faq, name='faq'),

    path("index/", views.index, name='index'),

    path("index2/", views.index2, name='index2'),

    path("pricing/", views.pricing, name='pricing'),

    path("signin/", views.signin, name='signin'),
    # path("signin_details/", views.signin_validate, name='signin_details'),


    path("signup/", views.signup, name='signup'),

    path("payment/", views.payment, name='payment'),


    path("welcome/", views.welcome, name='welcome'),


    # admin panel

    path("adindex1/", views.adindex1, name='index1'),

    path("adsignup1/", views.adsignup1, name='signup1'),

    path("adsignin1/", views.adsignin1, name='signin1'),
# package admin
    path("adpackage/", views.adpackage, name='adpackage'),
    path("adpackage_details/", views.adpackage1, name='adpackage'),

# director in admin
    path("adproducer/", views.addirector, name='director1'),
    path("addirector_details/", views.addirectorsdetail, name='director123'),
    
    



# category admin
    path("adcategory/", views.admcategory, name='category12'),
    


# director panel
    path("drindex1/", views.drindex1, name='index11'),

    # path("drsignup1/", views.drsignup1, name='signup1'),

    # path("drsignin1/", views.drsignin1, name='signup1'),

    # path("drpackage/", views.drpackage, name='package11'),

    # path("drcategory/", views.drcategory, name='packag12'),
    path("adcategory_details/", views.categoryDetails, name='packag12'),


    # path("drvediopage/", views.drvedio, name='advedio'),

    path('add/admin_master/', views.addAdminMaster),
    path('get_data/admin_master/', views.getAdminData, name='admin_master'),
    # path('update/admin_master/', views.updateAdminData, name='admin_master'),
    # path('delete/admin_master/', views.deleteAdminData, name='admin_master'),

    path("langauge_master/", views.langaugeMaster, name='langauge_master'),
    path("release_category/", views.releaseCategory, name='release_category'),
    path("movie_list/", views.movieList, name='movie_list'),
    path("subscription_details/", views.subscriptionDetails, name='subscription_details'),

    path("manage_movies/", views.manageMovies, name='manage_movies'),
    path("manage_tv_series/", views.manageTvSeries, name='manage_tv_series'),
    path("manage_episodes/", views.manageEpisodes, name='manage_episodes'),
    path("payment_details/", views.paymentDetails, name='payment_details'),

    path("admin_login_validate/", views.adminLoginValidate, name='admin_login_validate'),

    path("language_details/", views.languageDetails, name='language_details'),
    path("manage_movies_details/", views.manageMoviesDetails, name='manage_movies'),
    path("manage_tvSeries_details/", views.manageTvSeriesDetails1, name='manage_movies'),
    path("manage_episode_details/", views.manageEpisodeDetails, name='manage_movies'),

    path("get_first_four_item/", views.getFirstFourItem, name='manage_movies'),
    path("get_new_release_item/", views.getNewReleaseItem, name='manage_movies'),

    path("get_tv_series/", views.getTvSeries, name='manage_movies'),

    path("get_movie_details/", views.getMovieDetails, name='manage_movies'),
    path("get_package/", views.getPackage, name='manage_movies'),

    path("payment_details_user/", views.paymentUser, name='manage_movies'),
    path("register_details/", views.registerDetails, name='manage_movies'),
    path("user_login_validate/", views.userLoginValidate, name='manage_movies'),
    path("order/", views.order, name='order'),
    path("pay_success/", views.paySuccess, name='order'),

    path("get_tv_series_details/", views.getTvSeriesDetails, name='order'),
    path("get_episodes_details/", views.getEpisodesDetails, name='order'),
    path("get_episodes_video_details/", views.getEpisodesVideoDetails, name='order'),

    path("logout/", views.Logout, name='logout'),

    path("get_movie_details_admin/", views.getMovieDetailsAdmin, name='manage_movies'),
    
    path("payment_details_admin/", views.paymentDetailsAdmin, name='manage_movies'),

   path('submit_review/', views.submitReview, name='home'),
   path('get_review/', views.getReview, name='home'),

   path('open_subscription_producer_details/', views.openSubscriptionProducerDetails, name='home'),
   path('payment_details_producer/', views.paymentDetailsProducer, name='home'),

   path('free_movie_details1/', views.freeMovieDetails1, name='home'),
   path('free_movie_details2/', views.freeMovieDetails2, name='home'),
   path('free_movie_details3/', views.freeMovieDetails3, name='home'),
   path('free_movie_details4/', views.freeMovieDetails4, name='home'),
   path('free_movie_details5/', views.freeMovieDetails5, name='home'),
   path('free_movie_details6/', views.freeMovieDetails6, name='home'),


  path("get_new_release_item_search/", views.getNewReleaseItemSearch, name='manage_movies'),

    path("get_tv_series_search/", views.getTvSeriesSearch, name='manage_movies'),




















    




 


]
